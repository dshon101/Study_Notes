// ============================================================
//  CS Study Hub — Application Logic
//  Loads data from data.json, handles all UI interactions
// ============================================================

let COURSES = {};
let currentCourse = 'home';
let currentTopic = null;
let currentView = 'notes';

// ── INIT ─────────────────────────────────────────────────────
async function init() {
  try {
    const res = await fetch('data.json');
    COURSES = await res.json();
    setupSplash();
    showHome();
  } catch (e) {
    console.error('Failed to load data.json:', e);
    document.getElementById('mainContent').innerHTML =
      '<div style="padding:40px;color:#f76f6f;font-family:monospace">Error loading course data. Make sure data.json is in the same folder.</div>';
  }
}

// ── SPLASH SCREEN ─────────────────────────────────────────────
function setupSplash() {
  const splash = document.getElementById('splash');
  if (!splash) return;
  splash.addEventListener('click', dismissSplash);
  splash.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') dismissSplash(); });
}

function dismissSplash() {
  const splash = document.getElementById('splash');
  if (splash) splash.classList.add('hidden');
}

// ── COURSE SWITCHING ──────────────────────────────────────────
function switchCourse(course, tabEl) {
  currentCourse = course;
  currentTopic = null;
  currentView = 'notes';

  document.querySelectorAll('.course-tab').forEach(t => t.classList.remove('active'));
  if (tabEl) tabEl.classList.add('active');

  if (course === 'home') {
    document.getElementById('sidebarLogo').textContent  = 'CS Study Hub';
    document.getElementById('sidebarTitle').textContent = 'All Courses';
    document.getElementById('sidebarSub').textContent   = Object.keys(COURSES).length + ' courses · click to explore';
    document.getElementById('viewSwitcher').style.display = 'none';
    document.getElementById('navList').innerHTML = '';
    setAccent('#6b7280', '#4b5563', '#9ca3af');
    showHome();
    return;
  }

  const c = COURSES[course];
  if (!c) return;
  document.getElementById('sidebarLogo').textContent  = 'CS Study Hub';
  document.getElementById('sidebarTitle').textContent = c.name;
  document.getElementById('sidebarSub').textContent   = c.topics.length + ' topics · click to explore';
  setAccent(c.accent, c.accent2, c.accent3);

  if (c.comingSoon || c.topics.length === 0) {
    document.getElementById('viewSwitcher').style.display = 'none';
    document.getElementById('navList').innerHTML = '';
    showComingSoon(c);
    return;
  }

  document.getElementById('viewSwitcher').style.display = 'flex';
  document.querySelectorAll('.vsw-btn').forEach((b, i) => b.classList.toggle('active', i === 0));

  buildNav();
  showCourseWelcome();
}

function setAccent(a, a2, a3) {
  const r = document.documentElement.style;
  r.setProperty('--accent',  a);
  r.setProperty('--accent2', a2);
  r.setProperty('--accent3', a3);
}

// ── NAV ───────────────────────────────────────────────────────
function buildNav() {
  const c   = COURSES[currentCourse];
  const nav = document.getElementById('navList');
  nav.innerHTML = '';
  c.topics.forEach((t, i) => {
    const li = document.createElement('li');
    li.className = 'nav-item';
    li.innerHTML = `<span class="nav-num">${String(i + 1).padStart(2, '0')}</span><span class="nav-name">${t.short}</span>`;
    li.onclick = () => loadTopic(i);
    nav.appendChild(li);
  });
}

function setActiveNav(idx) {
  document.querySelectorAll('.nav-item').forEach((el, i) => el.classList.toggle('active', i === idx));
}

// ── VIEW SWITCHER ─────────────────────────────────────────────
function setView(v, btn) {
  currentView = v;
  document.querySelectorAll('.vsw-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  if (currentTopic !== null) loadTopic(currentTopic);
  else showCourseWelcome();
}

// ── HOME PAGE ─────────────────────────────────────────────────
function showHome() {
  const main       = document.getElementById('mainContent');
  const courseKeys = Object.keys(COURSES);

  const colorMap = {
    crypto:    'var(--crypto-accent)',
    forensics: 'var(--forensics-accent)',
    networks:  'var(--networks-accent)',
    cloud:     'var(--cloud-accent)',
    oop:       'var(--oop-accent)'
  };

  const totalTopics = courseKeys.reduce((sum, k) => sum + (COURSES[k].topics ? COURSES[k].topics.length : 0), 0);

  let html = `
    <div class="hero">
      <div class="hero-eyebrow">Complete Study Resource</div>
      <h1 class="hero-heading"><span style="color:#a78bfa">CS</span> Study Hub</h1>
      <p class="hero-desc">${courseKeys.length} courses covering Cryptography, Cyber Forensics, Computer Networks, Cloud Computing, and OOP with Java. Select a course from the sidebar to get started.</p>
      <div class="hero-tags">
        <span class="hero-tag">${courseKeys.length} Courses</span>
        <span class="hero-tag">${totalTopics} Topics</span>
        <span class="hero-tag">Short Notes</span>
        <span class="hero-tag">Q&amp;A Flashcards</span>
        <span class="hero-tag">Summary Cards</span>
      </div>
    </div>
    <div class="welcome">
  `;

  courseKeys.forEach(key => {
    const c   = COURSES[key];
    const col = colorMap[key] || '#888';
    html += `
      <div class="welcome-section-title">
        <div class="wst-dot" style="background:${col}"></div>
        ${c.name}
      </div>
      <div class="welcome-grid">
    `;
    if (!c.topics || c.topics.length === 0) {
      html += `<div class="welcome-card" data-course="${key}" onclick="switchCourse('${key}', document.querySelector('[data-course=${key}]'))">
        <div class="wc-num wc-locked">COMING SOON</div>
        <div class="wc-title wc-locked">${c.name} — Topics being prepared</div>
      </div>`;
    } else {
      c.topics.forEach((t, i) => {
        html += `<div class="welcome-card" data-course="${key}" onclick="navToCourse('${key}', ${i})">
          <div class="wc-num">${String(i + 1).padStart(2, '0')}</div>
          <div class="wc-title">${t.short}</div>
        </div>`;
      });
    }
    html += `</div>`;
  });

  html += `</div>`;
  main.innerHTML = html;
}

function navToCourse(courseKey, topicIdx) {
  const tab = document.querySelector(`.course-tab[data-course="${courseKey}"]`);
  switchCourse(courseKey, tab);
  setTimeout(() => loadTopic(topicIdx), 60);
}

// ── COMING SOON ───────────────────────────────────────────────
function showComingSoon(c) {
  document.getElementById('mainContent').innerHTML = `
    <div class="hero">
      <div class="hero-eyebrow">${c.name}</div>
      <h1 class="hero-heading"><span>${c.name}</span></h1>
      <p class="hero-desc">This course is currently being prepared. Check back soon!</p>
    </div>
    <div class="coming-soon">
      <div class="coming-soon-icon">🚧</div>
      <div class="coming-soon-title">Content Coming Soon</div>
      <div class="coming-soon-desc">We're compiling comprehensive notes, Q&amp;A flashcards, and summary cards for <strong>${c.name}</strong>.</div>
    </div>
  `;
}

// ── COURSE WELCOME ────────────────────────────────────────────
function showCourseWelcome() {
  const c    = COURSES[currentCourse];
  const main = document.getElementById('mainContent');
  let html   = `
    <div class="hero">
      <div class="hero-eyebrow">${c.name}</div>
      <h1 class="hero-heading"><span>${c.name}</span> Study Guide</h1>
      <p class="hero-desc">${c.topics.length} topics with notes, Q&amp;A flashcards, and summary cards.</p>
      <div class="hero-tags">
        <span class="hero-tag">${c.topics.length} Topics</span>
        <span class="hero-tag">Short Notes</span>
        <span class="hero-tag">Q&amp;A Flashcards</span>
        <span class="hero-tag">Summary Cards</span>
      </div>
    </div>
    <div class="welcome"><div class="welcome-grid">
  `;
  c.topics.forEach((t, i) => {
    html += `<div class="welcome-card" data-course="${currentCourse}" onclick="loadTopic(${i})">
      <div class="wc-num">${String(i + 1).padStart(2, '0')}</div>
      <div class="wc-title">${t.short}</div>
    </div>`;
  });
  html += `</div></div>`;
  main.innerHTML = html;
}

// ── TOPIC LOADER ──────────────────────────────────────────────
function loadTopic(idx) {
  currentTopic = idx;
  setActiveNav(idx);

  const c    = COURSES[currentCourse];
  const t    = c.topics[idx];
  const main = document.getElementById('mainContent');

  const titleWords = t.short.split(' ');
  const heroSpan   = titleWords[0];
  const heroRest   = titleWords.slice(1).join(' ');

  let html = `
    <div class="hero">
      <div class="hero-eyebrow">Topic ${String(idx + 1).padStart(2, '0')} of ${c.topics.length} — ${c.name}</div>
      <h1 class="hero-heading"><span>${heroSpan}</span> ${heroRest}</h1>
      <p class="hero-desc">${t.subtitle}</p>
    </div>
    <div class="content-area">
  `;

  if (currentView === 'notes') {
    html += renderNotes(t, idx);
  } else if (currentView === 'qa') {
    html += renderQA(t, idx);
  } else {
    html += renderSummary(t);
  }

  html += `</div>`;
  main.innerHTML = html;
  main.scrollTop = 0;
}

// ── RENDER: NOTES ─────────────────────────────────────────────
function renderNotes(t, idx) {
  let html = '';
  t.notes.forEach((n, ni) => {
    html += `
      <div class="note-block" id="nb-${idx}-${ni}">
        <div class="note-block-header" onclick="toggleNote('nb-${idx}-${ni}')">
          <span>${n.title}</span>
          <span class="nbh-arrow">▼</span>
        </div>
        <div class="note-block-body">${n.body}</div>
      </div>
    `;
  });
  html += `<div class="summary-strip"><strong>Summary:</strong> ${t.summary}</div>`;
  return html;
}

// ── RENDER: Q&A ───────────────────────────────────────────────
function renderQA(t, idx) {
  let html = `<p style="font-family:'DM Mono',monospace;font-size:11px;color:var(--text3);margin-bottom:18px;">Click any question to reveal the answer.</p>`;
  t.qa.forEach((item, qi) => {
    html += `
      <div class="qa-card" id="qa-${idx}-${qi}">
        <div class="qa-question" onclick="toggleQA('qa-${idx}-${qi}')">
          <span class="qa-qnum">Q${qi + 1}</span>
          <span class="qa-qtext">${item.q}</span>
          <span class="qa-reveal-hint">reveal ▾</span>
        </div>
        <div class="qa-answer">${item.a}</div>
      </div>
    `;
  });
  return html;
}

// ── RENDER: SUMMARY ───────────────────────────────────────────
function renderSummary(t) {
  let html = `<div class="summary-grid">`;
  t.sumCards.forEach(card => {
    html += `<div class="sum-card">
      <div class="sum-card-label">${card.label}</div>
      <div class="sum-card-content">${card.content}</div>
    </div>`;
  });
  html += `</div>`;
  html += `<div class="summary-strip"><strong>Summary:</strong> ${t.summary}</div>`;
  return html;
}

// ── TOGGLES ───────────────────────────────────────────────────
function toggleNote(id) {
  document.getElementById(id).classList.toggle('open');
}

function toggleQA(id) {
  document.getElementById(id).classList.toggle('revealed');
}

// ── BOOTSTRAP ─────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', init);
